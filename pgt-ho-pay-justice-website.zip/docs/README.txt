UPLOAD YOUR SCANNED NOTIFICATIONS HERE
========================================

Upload your document images to this "docs" folder using EXACTLY these filenames.
The website will automatically detect and display them — no code editing required.

REQUIRED FILENAMES (must match exactly, case-sensitive):

1. federal-notification-2020.jpg
   -> M/o NHS,R&C Notification, 27 Jan 2020 (F.No.9-24/2016-E-I)

2. bps-allowances-2020.jpg
   -> BPS Doctors Allowances Notification, 30 Sep 2020 (F.No.10-368/2019-H-I)

3. kemu-2024.jpg
   -> KEMU Punjab PGT Revision, 27 Jul 2024 (No.9426/KEMU)

4. kemu-2025.jpg
   -> KEMU Punjab PGT Revision, 23 Oct 2025 (No.11428/KEMU)

5. phf-advisory-2025.jpg
   -> Punjab Health Foundation Advisory, 16 Jan 2025 (PHF/ADMIN/3758)

6. cpsp-2026.jpg
   -> CPSP Accreditation Requirements Point 6, 09 Jun 2026

7. pmdc-2025.jpg
   -> PM&DC Public Notice, 29 Aug 2025

8. shifa-salary.jpg
   -> Shifa International PGME Salary Schedule

9. aku-salary.jpg
   -> Aga Khan University Resident Salary Structure

HOW TO UPLOAD ON GITHUB:
1. Go to your repository on github.com
2. Navigate into the "docs" folder
3. Click "Add file" -> "Upload files"
4. Drag your scanned images in, renaming each to match the filenames above
5. Click "Commit changes"
6. Refresh your live site after ~1 minute — images will appear automatically

TIP: If a file is missing, the website automatically shows a clean placeholder
box instead of a broken image — so it's safe to upload these gradually.
